package com.kochhealth.vitals_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VitalsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(VitalsServiceApplication.class, args);
	}

}
